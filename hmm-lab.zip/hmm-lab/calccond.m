function plett = calccond(seq, l1, mode);

%
% function plett = calccond(seq, l1, mode)
%
% This function calculates the conditional probabilites 
% P(x|l1) for all letters x, regardless of the position 
% along the chain. If mode is given then no information
% is printed.
% 
% Author: Mattias Ohlsson, 
%         Theoretical Physics, 
%         Complex Systems Division
%         mattias@thep.lu.se
% 
% Last date of change: August 2012

% Check for the mode parameter
if nargin == 3
  sil = 1;
else
  sil = 0;
end

% Define the alphabet
lett = ['A' 'C' 'D' 'E' 'F' 'G' 'H' 'I' 'K' 'L' ...
	'M' 'N' 'P' 'Q' 'R' 'S' 'T' 'V' 'W' 'Y'];
nolett = 20;

% Make sure it is uppercase
l1 = upper(l1);

% Here we go

if sil == 0
  disp(sprintf('\nCalculating P(x|%s) for the dataset %s\n', l1, seq.dname));
end

for i=1:nolett
  
  [nA, nAB, plett(i), lstd(i)] = getpBgA(seq, lett(i), l1);
  if sil == 0
    disp(sprintf('P(%s|%s) = %5.1f %%  +- %5.1f %%   (N = %d)', ...
                 lett(i), l1, 100*plett(i), 100*lstd(i), nAB));
  end
end
