function permtest(seq, subseq, nperm, nhist);

%
% function permtest(seq, subseq, nperm)
%
% This function performs a permutation test for the occurence 
% of the suqsequence subseq among all sequences in seq. The 
% nperm parameter gives the number of permutations tests to
% perform.
%
% Author: Mattias Ohlsson, 
%         Theoretical Physics, 
%         Complex Systems Division
%         mattias@thep.lu.se
% 
% Last date of change: August 2012

close all;
n = 0;
norm = 0;
sseq = upper(subseq);

if nargin == 3
  nbin = 15;
else
  nbin = nhist;
end

% First collect all sequences
a = '';
for i=1:seq.noseq
  len = seq.seqlen(i);
  a = [a seq.seqmat(i,1:len)];
end

% Find the original number of counts
n0 = length( findstr(a, sseq) );

len = length(a);
b = a;

h = waitbar(0,'Performing permutation test...');

for n=1:nperm
  b = b(randperm(len));
  np(n) = length( findstr(b, sseq) );
  waitbar(n/nperm);
end
close(h);
[bins, xout] = hist(np,nbin);
bar(xout, bins);
hold on;
line([n0,n0],[0,max(bins)], 'Color', 'red');
str = sprintf('Distribution of subsequence %s. Red line the original count (%d)', sseq, n0);
title(str);
ylabel('Number of random proteins sequences');
xstr = sprintf('Number of %s pairs', sseq);
xlabel(xstr);
