function [seq, setid] = loaddata(dset)

%
% function [seq, setid] = loaddata
%
% This function loads fasta sequences from pre-defined sets. 
% The sequences are stored in the structure seq.
%
% Author: Mattias Ohlsson, 
%         Theoretical Physics, 
%         Complex Systems Division
%         mattias@thep.lu.se
% 
% Last date of change: August 2012

% Set path to data directory
DataPath = '.';

if nargin == 0
  ask = 1;
else
  ask = 0;
  tmp = dset;
end

N_0 = 1000;
tot_0 = 370226;
N_1 = 700;
tot_1 = 232753;
N_2 = 300;
tot_2 = 148955;

% Ask what set to load
if ask == 1
  disp(sprintf('Choose one of the following sets of amino acid sequences:\n'));
  disp(sprintf('Set number  Name'));
  disp(sprintf('  1         hemn    (%d sequences and a total %d aa)', N_0, tot_0));
  disp(sprintf('  2         dak2    (%d sequences and a total %d aa)', N_1, tot_1));
  disp(sprintf('  3         sap     (%d sequences and a total %d aa)', N_2, tot_2));
  tmp=input('\n which set (give the number)? (default 2): ');
end
if isempty(tmp) == 1
  seqset = 'dak2';
  setid = 2;
elseif tmp == 1
  seqset = 'hemn';
  setid = 1;
elseif tmp == 2
  seqset = 'dak2';
  setid = 2;
elseif tmp == 3
  seqset = 'sap';
  setid = 3;
elseif tmp == 4
  seqset = 'hemn_t';
  setid = 4;
elseif tmp == 5
  seqset = 'dak2_t';
  setid = 5;
elseif tmp == 6
  seqset = 'sap_t';
  setid = 6;
end

% Load the file into the workspace
load([DataPath '/' seqset]);
