function freq = calcfreq(seq, mode);

%
% function freq = calcfreq(seq)
%
% This function calculates the frequences for each of the 20 amino acids in
% the set of sequences contained in the seq structure.
% 
%
% Author: Mattias Ohlsson, 
%         Theoretical Physics, 
%         Complex Systems Division
%         mattias@thep.lu.se
% 
% Last date of change: August 2012

lett = ['A' 'C' 'D' 'E' 'F' 'G' 'H' 'I' 'K' 'L' ...
	'M' 'N' 'P' 'Q' 'R' 'S' 'T' 'V' 'W' 'Y'];
nolett = 20;

% Simple probabilities for the letters in Lett
check = 0.0;
Norm = sum(seq.seqlen);

if nargin == 2
  sil = 1;
else
  sil = 0;
end

if sil == 0
  disp(sprintf('\nCalculating P(x) for the dataset %s\n', seq.dname));
end

for i=1:nolett
  
  totno = 0;
  for j=1:seq.noseq
    len = seq.seqlen(j);
    tmp = find(seq.seqmat(j,1:len)==lett(i));
    no = length(tmp);
    totno = totno + no;
    ptmp(j) = no / len;
  end
  prob(i) = mean(ptmp);
  probstd(i) = std(ptmp);
  nfound(i) = totno;
  check = check + prob(i);

  if sil == 0
    disp(sprintf('P(%s) = %5.1f %%  +- %5.1f %%   (N = %d)', ...
                 lett(i), 100*prob(i), 100*probstd(i), nfound(i)));
  end
  
end

% Make a nice figure
if sil == 0
  fig1 = figure;
  title(seq.dname);
  hold on;
  errorbar(100*prob,100*probstd,'o');
  axis tight;
  xlabel('Amino Acids');
  ylabel('Frequency (%)');
  title(seq.dname);
  grid on;
  sc = max(prob) / 20;
  text([1:20],100*(prob+sc),lett');
  line([0 20],[5 5]);
  text(10,5,'Random');
  drawnow;
end

freq = prob;
