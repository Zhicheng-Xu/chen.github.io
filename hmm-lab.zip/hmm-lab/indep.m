function indep(seq);

% 
% function indep(seq);
%
% This function computes P(a)*P(b) and P(a)*P(b|a) and check
% for differences and similarites among the 20*20 possible
% pairs of amino acids
% 
%
% Author: Mattias Ohlsson, 
%         Theoretical Physics, 
%         Complex Systems Division
% 
% Last date of change: August 2012
% 
close all;
format long;

% Define the alphabet
lett = ['A' 'C' 'D' 'E' 'F' 'G' 'H' 'I' 'K' 'L' ...
	'M' 'N' 'P' 'Q' 'R' 'S' 'T' 'V' 'W' 'Y'];
nolett = 20;

% This next command calculates the frequences for each of the AA's
freq = calcfreq(seq, 1);

% For the impatient
h = waitbar(0,'Calculating a lot of conditional probabilities...');

cnt = 0;
for i=1:nolett,

  cfreq = calccond(seq, lett(i), 1);
  
  for j=1:nolett,

    cnt = cnt + 1;
    p1 = freq(i) * freq(j);
    p2 = freq(i) * cfreq(j);
    
    diff = p1 - p2;
    adiff = abs(diff);
    
    aux1(cnt,:) = [diff, i, j];
    aux2(cnt,:) = [adiff, i, j];

    waitbar(cnt/(nolett*nolett));

  end
end
close(h);

disp(sprintf('Largest differences:'));
tmp = sortrows(aux1,1);
myprint(1, tmp, lett, freq, seq);
myprint(2, tmp, lett, freq, seq);
myprint(400, tmp, lett, freq, seq);
myprint(399, tmp, lett, freq, seq);

disp(sprintf('\nSmallest differences:'));
tmp = sortrows(aux2,1);
myprint(1, tmp, lett, freq, seq);
myprint(2, tmp, lett, freq, seq);

disp(sprintf('\nA few random pairs:'));
idx = randi(400,1);
myprint(idx, tmp, lett, freq, seq);
idx = randi(400,1);
myprint(idx, tmp, lett, freq, seq);
idx = randi(400,1);
myprint(idx, tmp, lett, freq, seq);

function myprint(idx, tmp, lett, freq, seq);

i1 = tmp(idx,2); i2 = tmp(idx,3); l1 = lett(i1); l2 = lett(i2);
cfreq = calccond(seq, lett(i1), 1);
disp(sprintf('%s%s: P(%s)P(%s) = %f  P(%s)P(%s|%s) = %f, P(%s|%s) = %f', ...
             l1,l2,l1,l2, freq(i1)*freq(i2), l1,l2,l1, freq(i1)*cfreq(i2), ...
             l2,l1, cfreq(i2)));


