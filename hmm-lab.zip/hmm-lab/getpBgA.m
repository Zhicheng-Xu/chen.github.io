function [nA, nAB, pAB, pABstd] = getpBgA(seq, B, A);

%
% function [nA, nAB, pAB, pABstd] = getpBgA(seq, B, A)
% 
% This function computes the conditional probability P(A|B) for the
% sequences found in seq. The return values are:
%
% nA     = number of 'A's found
% nAB    = number of 'AB's found
% pAB    = the conditional probability
% pABstd = the standard deviation 
% 
%
% Author: Mattias Ohlsson, 
%         Theoretical Physics, 
%         Complex Systems Division
%         mattias@thep.lu.se
% 
% Last date of change: September 2012

nA = 0;
nAB = 0;
nok = 0;
for i=1:seq.noseq
  
  len = seq.seqlen(i);
  a = seq.seqmat(i,1:len);
  nA_seq = length(findstr(a, A) ) - length( find( a(end) == A) );
  
  AB = [A B];
  nAB_seq = length( findstr(a, AB) );
  
  if nA_seq > 0 
    nok = nok + 1;
    pAB_seq(nok) = nAB_seq / nA_seq;
    nA = nA + nA_seq;
    nAB = nAB + nAB_seq;
  end
    
end  

% Get the probability
pAB = mean(pAB_seq);
pABstd = std(pAB_seq);
