% This is the main matlab program for exercise 1 for the 
% BIM083 /BNF071 course. The program is started from the matlab
% prompt by just typing select.
%
% Author: Mattias Ohlsson, 
%         Theoretical Physics, 
%         Complex Systems Division
% 
% Last date of change: August 2012
% 
clear all;
close all;
format long;

% Define the alphabet
lett = ['A' 'C' 'D' 'E' 'F' 'G' 'H' 'I' 'K' 'L' ...
	'M' 'N' 'P' 'Q' 'R' 'S' 'T' 'V' 'W' 'Y'];

% Load the data
seq = loaddata;

disp(sprintf('\nYou have now loaded the data set %s into the ', seq.dname));
disp(sprintf(['Matlab variable seq. To select another data set rerun this' ...
	      ' function.\n']));
