function fig2ps(psname);

% fig2ps(psname);
%
% This function saves the current figure on your screen as
% as a postcript file with the name psname.eps
%
% April 1999, Mattias Ohlsson
% Email: mattias@thep.lu.se

eval(['print ' psname ' -deps2']);
