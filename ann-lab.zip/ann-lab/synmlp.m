% syn_mlp
%
% This function trains a MLP for the three synthetic data sets.
%
% June 2003, Mattias Ohlsson
% Email: mattias@thep.lu.se

% Clear all thing before
clear all;
close all;

% Define the problem
disp(sprintf('Choose problem:'));
disp(sprintf('Synthetic data I    = 1'));
disp(sprintf('Synthetic data II   = 2'));
disp(sprintf('Synthetic data III  = 3'));
tmp=input('\nproblem? (default 1): ');
if isempty(tmp) == 1
  problem = 1;
else
  problem=tmp;
end

% We use 100 datapoints for all problems
Ndata = 100;

% Initialize the random number generator
tmp = input('Seed to the random number generator (Default current time): ');
if tmp > 0
  rand('state',tmp);
  randn('state',tmp);
else
  rand('state',sum(100*clock));
  randn('state',sum(100*clock));
end

% Load training and validation data
if problem == 1
  % Load artificial data I
  [P,T] = loadsyn1(Ndata);
  [Pv,Tv] = loadsyn1(Ndata*20);
elseif problem == 2
  % Load artificial data II
  [P,T] = loadsyn2x(Ndata);
  [Pv,Tv] = loadsyn2x(Ndata*20);
elseif problem == 3
  % Load artificial data II
  [P,T] = loadsyn3(Ndata);
  [Pv,Tv] = loadsyn3(Ndata*20);
else
  error('Use 1, 2 or 3 to select the problem type');
end

% Ask for the number of hidden nodes
tmp = input('Number of hidden nodes? [2] ');
if tmp > 0
  nodes=tmp;
else
  nodes=2;
end

% The minimization method
if nodes <= 4
  method='traingdx';
else
  method='trainlm';
end

% Create a MLP with initialization
nnver = ver('nnet');
if strcmp(nnver.Version, '5.0.2')
  net = newff(minmax(P),[nodes 1],{'tansig' 'logsig'},[method]);
else
  net = newff(P,T,nodes,{'tansig' 'logsig'},[method]);
  net.outputs{2}.processFcns = {};  
end

% Train this network with train
tmp = input('Number of epochs? [400] ');
if tmp > 0
  epoch=tmp;
else
  epoch=400;
end
net.trainParam.epochs = epoch;

% This is to make train show the validation errors during training
TV.P = Pv;
TV.T = Tv;
net = train(net,P,T,[],[],[],TV);

% Plot the results
plotres(net,P,T,'Training data');
plotres(net,Pv,Tv,'Validation data');

% Perform some analysis on the result
Y = sim(net,P);
[spec, sens, tot, None, Nzero, miss] = stat(Y, T);

disp(sprintf('\n'));
disp(sprintf('Results for the training:'));
disp(sprintf('Total number of data: %d (%d ones and %d zeros)', ...
	     length(T), None, Nzero)); 
disp(sprintf('Number of misses: %d (%5.2f%% performance)', miss, tot));
disp(sprintf('Specificity: %5.2f%% (Success for class 0)', spec));
disp(sprintf('Sensitivity: %5.2f%% (Success for class 1)', sens));

% The validation data
Yv = sim(net,Pv);
[specv, sensv, totv, Nonev, Nzerov, missv] = stat(Yv, Tv);

disp(sprintf('\nResults for the validation:'));
disp(sprintf('Total number of data: %d (%d ones and %d zeros)', ...
	     length(Tv), Nonev, Nzerov)); 
disp(sprintf('Number of misses: %d (%5.2f%% performance)', ...
	     missv, totv));
disp(sprintf('Specificity: %5.2f%% (Success for class 0)', specv));
disp(sprintf('Sensitivity: %5.2f%% (Success for class 1)', sensv));

% Now produce a boundary
tmp = input('\nPlot the boundary (1/0)? [1] ' );
if isempty(tmp) == 1
  bound = 1;
else
  bound = tmp;
end

if bound == 1
  if nodes <= 4
    boundary(net, P, T, 1000, 0.5, 0.1);
  else
    boundary(net, P, T, 1000, 0.5, 0.2);
  end
end
