function [P,T] = loadsyn2x(N)

% function [P,T] = loadsyn1(N)
%
% Generates N 2-dimensional data points sampled from two overlapping normal
% distributions. The data are stored in P and the class-membership in T.
%
% March 1999, Mattias Ohlsson
% Email: mattias@thep.lu.se

if nargin < 1
  error('You must give the number of points as input argument')
end
if nargout < 2 
  error('You must provide vectors/matrices P and T for output')
end

N2 = round(N/2);
ss = 0.65;
dd = 0.8;

% The positives
x = [0:2*pi/N2:2*pi];
[M,N2] = size(x);
y = sin(x) + ss*randn(1,N2) + dd;
P1 = [x;y];

% The negatives
y = sin(x) + ss*randn(1,N2) - dd;
P2 = [x;y];

% Total input
P = [P1 P2];
P = mapstd(P);

% The targets
T(1,1:N2) = ones(1,N2);
T(1,N2+1:2*N2) = zeros(1,N2);
