function [P,T] = loadsyn2(N)

% function [P,T] = loadsyn1(N)
%
% Generates N 2-dimensional data points sampled from two overlapping normal
% distributions. The data are stored in P and the class-membership in T.
%
% March 1999, Mattias Ohlsson
% Email: mattias@thep.lu.se

if nargin < 1
  error('You must give the number of points as input argument')
end
if nargout < 2 
  error('You must provide vectors/matrices P and T for output')
end

N1 = round(N/4);
Nf = 4 * N1;
ss = 0.42;

% The positives
Px(1,1:N1)=1+ss*randn(1,N1);
Px(2,1:N1)=1+ss*randn(1,N1);
P = Px;

Px(1,1:N1)=3+ss*randn(1,N1);
Px(2,1:N1)=1+ss*randn(1,N1);
P = [P Px];

% The negatives
Px(1,1:N1)=2+ss*randn(1,N1);
Px(2,1:N1)=1.5+ss*randn(1,N1);
P = [P Px];

% The negatives
Px(1,1:N1)=0+ss*randn(1,N1);
Px(2,1:N1)=2+ss*randn(1,N1);
P = [P Px];

% The targets
T(1,1:2*N1)=ones(1,2*N1);
T(1,2*N1+1:Nf)=zeros(1,Nf-2*N1);
